// ══════════════════════════════════════════════════════════
// MEETFLOW - BACKEND SERVER (Node.js + Express + SQLite)
// Hệ thống đặt lịch họp công ty XYZ
// ══════════════════════════════════════════════════════════
const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// ── DATABASE ──
const db = new Database(path.join(__dirname, 'meetflow.db'));
db.pragma('journal_mode = WAL');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  fullname TEXT NOT NULL,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  password_plain TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'employee',
  status TEXT NOT NULL DEFAULT 'active',
  created_at TEXT DEFAULT (datetime('now')),
  last_login TEXT
);

CREATE TABLE IF NOT EXISTS rooms (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT UNIQUE NOT NULL,
  capacity INTEGER DEFAULT 0,
  floor TEXT,
  equipment TEXT,
  color TEXT DEFAULT 'indigo',
  status TEXT DEFAULT 'available',
  is_custom INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS meetings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  date TEXT NOT NULL,
  start_time TEXT NOT NULL,
  end_time TEXT NOT NULL,
  room TEXT NOT NULL,
  creator_id INTEGER NOT NULL,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY(creator_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  type TEXT NOT NULL,
  action TEXT NOT NULL,
  by_user TEXT,
  detail TEXT,
  time TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS participants (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  meeting_id INTEGER NOT NULL,
  user_id INTEGER,
  name TEXT NOT NULL,
  FOREIGN KEY(meeting_id) REFERENCES meetings(id),
  FOREIGN KEY(user_id) REFERENCES users(id)
);
`);

// Seed default rooms if empty
const roomCount = db.prepare('SELECT COUNT(*) c FROM rooms').get().c;
if (roomCount === 0) {
  const ins = db.prepare('INSERT INTO rooms (name, capacity, floor, equipment, color) VALUES (?,?,?,?,?)');
  ins.run('Phòng A', 10, 'Tầng 3', 'Máy chiếu, TV', 'indigo');
  ins.run('Phòng B', 6, 'Tầng 3', 'TV, Micro', 'purple');
  ins.run('Phòng C', 20, 'Tầng 5', 'Máy chiếu, Micro, Loa', 'amber');
}

// Seed tài khoản Admin mặc định nếu hệ thống chưa có Admin nào
const adminCount = db.prepare("SELECT COUNT(*) c FROM users WHERE role = 'admin'").get().c;
if (adminCount === 0) {
  const DEFAULT_ADMIN_USER = 'admin';
  const DEFAULT_ADMIN_PASS = 'Admin@123';
  const hash = bcrypt.hashSync(DEFAULT_ADMIN_PASS, 10);
  db.prepare(
    'INSERT OR IGNORE INTO users (fullname, username, password_hash, password_plain, role, status) VALUES (?,?,?,?,?,?)'
  ).run('Quản trị viên hệ thống', DEFAULT_ADMIN_USER, hash, DEFAULT_ADMIN_PASS, 'admin', 'active');
  console.log('──────────────────────────────────────────────');
  console.log(`👑 Đã tạo tài khoản Admin mặc định:`);
  console.log(`   Tên đăng nhập: ${DEFAULT_ADMIN_USER}`);
  console.log(`   Mật khẩu:      ${DEFAULT_ADMIN_PASS}`);
  console.log('──────────────────────────────────────────────');
}

function addLog(type, action, by_user, detail) {
  db.prepare('INSERT INTO logs (type, action, by_user, detail) VALUES (?,?,?,?)').run(type, action, by_user, detail || '');
}

// ── MIDDLEWARE ──
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: 'meetflow-xyz-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 * 8 } // 8h
}));

function requireAuth(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: 'Chưa đăng nhập' });
  next();
}

// ══════════════════════════════════════════
// US01 - ĐĂNG KÝ TÀI KHOẢN
// ══════════════════════════════════════════
app.post('/api/register', (req, res) => {
  let { fullname, username, password } = req.body;
  fullname = (fullname || '').trim();
  username = (username || '').trim().toLowerCase();
  password = password || '';

  if (!fullname || !username || !password) {
    return res.status(400).json({ error: 'Vui lòng điền đầy đủ Họ tên, Tên đăng nhập, Mật khẩu.' });
  }
  if (password.length < 8) {
    return res.status(400).json({ error: 'Mật khẩu phải có tối thiểu 8 ký tự.' });
  }
  const exists = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
  if (exists) {
    return res.status(409).json({ error: 'Tên đăng nhập đã tồn tại trong hệ thống.' });
  }
  const hash = bcrypt.hashSync(password, 10);
  const info = db.prepare(
    'INSERT INTO users (fullname, username, password_hash, password_plain, role, status) VALUES (?,?,?,?,?,?)'
  ).run(fullname, username, hash, password, 'employee', 'active');

  addLog('Tài khoản', `Đăng ký tài khoản mới`, username, fullname);
  res.json({ ok: true, id: info.lastInsertRowid });
});

// ══════════════════════════════════════════
// US02 - ĐĂNG NHẬP
// ══════════════════════════════════════════
app.post('/api/login', (req, res) => {
  let { username, password, expectedRole } = req.body;
  username = (username || '').trim().toLowerCase();
  const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);

  if (!user || !bcrypt.compareSync(password || '', user.password_hash)) {
    return res.status(401).json({ error: 'Sai tên đăng nhập hoặc mật khẩu.' });
  }
  if (user.status === 'locked') {
    return res.status(403).json({ error: 'Tài khoản của bạn đã bị khóa. Liên hệ Administrator.' });
  }
  if (expectedRole && user.role !== expectedRole) {
    const roleName = { admin: 'Quản trị viên', employee: 'Nhân viên' };
    return res.status(403).json({
      error: `Tài khoản này là ${roleName[user.role] || user.role}, vui lòng chọn đúng vai trò để đăng nhập.`
    });
  }
  db.prepare("UPDATE users SET last_login = datetime('now') WHERE id = ?").run(user.id);
  req.session.user = { id: user.id, fullname: user.fullname, username: user.username, role: user.role };
  addLog('Tài khoản', 'Đăng nhập hệ thống', username, '');
  res.json({ ok: true, user: req.session.user });
});

app.post('/api/logout', (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get('/api/me', (req, res) => {
  if (!req.session.user) return res.status(401).json({ error: 'Chưa đăng nhập' });
  res.json({ user: req.session.user });
});

// ══════════════════════════════════════════
// US03 - KHÔI PHỤC MẬT KHẨU
// (Theo đúng đặc tả: nếu tìm thấy tài khoản, trả về mật khẩu hiện tại)
// ══════════════════════════════════════════
app.post('/api/forgot-password', (req, res) => {
  let { username } = req.body;
  username = (username || '').trim().toLowerCase();
  const user = db.prepare('SELECT username, password_plain FROM users WHERE username = ?').get(username);
  if (!user) {
    return res.status(404).json({ error: 'Không tìm thấy tài khoản trong hệ thống.' });
  }
  addLog('Tài khoản', 'Yêu cầu khôi phục mật khẩu', username, '');
  res.json({ ok: true, password: user.password_plain });
});

// ══════════════════════════════════════════
// US04/US05/US06 - LỊCH HỌP: DANH SÁCH, TÌM KIẾM, LỌC, SẮP TỚI
// ══════════════════════════════════════════
app.get('/api/meetings', requireAuth, (req, res) => {
  const { q, room } = req.query;
  let sql = `SELECT m.*, u.fullname as creator_name FROM meetings m
             JOIN users u ON u.id = m.creator_id WHERE 1=1`;
  const params = [];
  if (q) { sql += ' AND m.title LIKE ?'; params.push(`%${q}%`); }
  if (room && room !== 'all') { sql += ' AND m.room = ?'; params.push(room); }
  sql += ' ORDER BY m.date, m.start_time';
  res.json(db.prepare(sql).all(...params));
});

app.get('/api/meetings/upcoming', requireAuth, (req, res) => {
  const now = new Date();
  const nowDate = now.toISOString().slice(0, 10);
  const nowTime = now.toTimeString().slice(0, 5);
  const rows = db.prepare(`
    SELECT * FROM meetings
    WHERE date > ? OR (date = ? AND start_time >= ?)
    ORDER BY date, start_time LIMIT 5
  `).all(nowDate, nowDate, nowTime);
  res.json(rows);
});

// ══════════════════════════════════════════
// TÍNH NĂNG MỚI 1 - CHI TIẾT NGƯỜI THAM GIA CUỘC HỌP
// ══════════════════════════════════════════
app.get('/api/meetings/:id', requireAuth, (req, res) => {
  const m = db.prepare(`
    SELECT m.*, u.fullname as creator_name FROM meetings m
    JOIN users u ON u.id = m.creator_id WHERE m.id = ?`).get(req.params.id);
  if (!m) return res.status(404).json({ error: 'Không tìm thấy cuộc họp.' });
  const participants = db.prepare('SELECT * FROM participants WHERE meeting_id = ?').all(req.params.id);
  res.json({ ...m, participants });
});

app.get('/api/meetings/:id/participants', requireAuth, (req, res) => {
  res.json(db.prepare('SELECT * FROM participants WHERE meeting_id = ?').all(req.params.id));
});

app.post('/api/meetings/:id/participants', requireAuth, (req, res) => {
  const meeting = db.prepare('SELECT * FROM meetings WHERE id = ?').get(req.params.id);
  if (!meeting) return res.status(404).json({ error: 'Không tìm thấy cuộc họp.' });
  let { user_id, name } = req.body;
  if (user_id) {
    const u = db.prepare('SELECT fullname FROM users WHERE id = ?').get(user_id);
    if (!u) return res.status(404).json({ error: 'Không tìm thấy người dùng.' });
    name = u.fullname;
  }
  name = (name || '').trim();
  if (!name) return res.status(400).json({ error: 'Vui lòng chọn hoặc nhập tên người tham gia.' });
  const info = db.prepare('INSERT INTO participants (meeting_id, user_id, name) VALUES (?,?,?)')
    .run(req.params.id, user_id || null, name);
  res.json({ ok: true, id: info.lastInsertRowid, name });
});

app.delete('/api/meetings/:id/participants/:pid', requireAuth, (req, res) => {
  db.prepare('DELETE FROM participants WHERE id = ? AND meeting_id = ?').run(req.params.pid, req.params.id);
  res.json({ ok: true });
});

// Danh sách người dùng đơn giản (mọi tài khoản đã đăng nhập đều xem được, để chọn người tham gia)
app.get('/api/users/list', requireAuth, (req, res) => {
  res.json(db.prepare("SELECT id, fullname, username FROM users WHERE status = 'active' ORDER BY fullname").all());
});

// Danh sách nhân viên (mọi tài khoản đăng nhập đều xem được, kèm số cuộc họp đã tạo)
app.get('/api/staff', requireAuth, (req, res) => {
  const rows = db.prepare(`
    SELECT u.id, u.fullname, u.username, u.role, u.status,
           (SELECT COUNT(*) FROM meetings m WHERE m.creator_id = u.id) AS meeting_count
    FROM users u
    ORDER BY u.fullname
  `).all();
  res.json(rows);
});

// ══════════════════════════════════════════
// TÍNH NĂNG MỚI 2 - THỐNG KÊ TỔNG QUAN
// ══════════════════════════════════════════
app.get('/api/stats', requireAuth, (req, res) => {
  const totalMeetings = db.prepare('SELECT COUNT(*) c FROM meetings').get().c;
  const totalRooms = db.prepare('SELECT COUNT(*) c FROM rooms').get().c;
  const myMeetings = db.prepare('SELECT COUNT(*) c FROM meetings WHERE creator_id = ?').get(req.session.user.id).c;
  const now = new Date();
  const weekDates = Array.from({ length: 7 }, (_, i) => {
    const day = now.getDay() === 0 ? 7 : now.getDay();
    const monday = new Date(now); monday.setDate(now.getDate() - day + 1 + i);
    return monday.toISOString().slice(0, 10);
  });
  const meetingsThisWeek = db.prepare(
    `SELECT COUNT(*) c FROM meetings WHERE date IN (${weekDates.map(() => '?').join(',')})`
  ).get(...weekDates).c;
  const mostUsedRoom = db.prepare(
    'SELECT room, COUNT(*) cnt FROM meetings GROUP BY room ORDER BY cnt DESC LIMIT 1'
  ).get();
  const result = { totalMeetings, totalRooms, myMeetings, meetingsThisWeek, mostUsedRoom: mostUsedRoom || null };
  if (req.session.user.role === 'admin') {
    result.totalUsers = db.prepare('SELECT COUNT(*) c FROM users').get().c;
    result.lockedUsers = db.prepare("SELECT COUNT(*) c FROM users WHERE status = 'locked'").get().c;
  }
  res.json(result);
});

// ══════════════════════════════════════════
// TÍNH NĂNG MỚI 3 - HỒ SƠ CÁ NHÂN (đổi tên / mật khẩu)
// ══════════════════════════════════════════
app.patch('/api/me', requireAuth, (req, res) => {
  let { fullname, currentPassword, newPassword } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.session.user.id);
  fullname = (fullname || '').trim();
  if (fullname) {
    db.prepare('UPDATE users SET fullname = ? WHERE id = ?').run(fullname, user.id);
    req.session.user.fullname = fullname;
  }
  if (newPassword) {
    if (!bcrypt.compareSync(currentPassword || '', user.password_hash)) {
      return res.status(401).json({ error: 'Mật khẩu hiện tại không đúng.' });
    }
    if (newPassword.length < 8) {
      return res.status(400).json({ error: 'Mật khẩu mới phải có tối thiểu 8 ký tự.' });
    }
    const hash = bcrypt.hashSync(newPassword, 10);
    db.prepare('UPDATE users SET password_hash = ?, password_plain = ? WHERE id = ?').run(hash, newPassword, user.id);
  }
  addLog('Tài khoản', 'Cập nhật hồ sơ cá nhân', user.username, '');
  res.json({ ok: true, user: req.session.user });
});

// ══════════════════════════════════════════
// US07/US08 - TẠO LỊCH HỌP + KIỂM TRA TRÙNG PHÒNG (<<include>>)
// ══════════════════════════════════════════
app.post('/api/meetings', requireAuth, (req, res) => {
  let { title, date, start_time, end_time, room, force } = req.body;
  title = (title || '').trim();
  room = (room || '').trim();

  if (!title || !date || !start_time || !end_time || !room) {
    return res.status(400).json({ error: 'Vui lòng điền đầy đủ Tiêu đề, Ngày, Giờ bắt đầu/kết thúc, Phòng họp.' });
  }
  if (start_time >= end_time) {
    return res.status(400).json({ error: 'Giờ bắt đầu phải nhỏ hơn giờ kết thúc.' });
  }

  // <<include>> Kiểm tra trùng lịch phòng họp
  const conflicts = db.prepare(`
    SELECT m.*, u.fullname as creator_name FROM meetings m
    JOIN users u ON u.id = m.creator_id
    WHERE m.date = ? AND m.room = ? AND (? < m.end_time AND ? > m.start_time)
  `).all(date, room, start_time, end_time);

  if (conflicts.length > 0 && !force) {
    return res.status(409).json({ conflict: true, conflicts });
  }

  // Nếu phòng tự nhập chưa tồn tại trong danh mục -> tự thêm (màu hồng cánh sen)
  const roomExists = db.prepare('SELECT id FROM rooms WHERE name = ?').get(room);
  if (!roomExists) {
    db.prepare('INSERT INTO rooms (name, color, is_custom) VALUES (?,?,1)').run(room, 'pink');
  }

  const info = db.prepare(`
    INSERT INTO meetings (title, date, start_time, end_time, room, creator_id)
    VALUES (?,?,?,?,?,?)
  `).run(title, date, start_time, end_time, room, req.session.user.id);

  // <<include>> Gửi thông báo (mô phỏng qua log hệ thống)
  addLog('Lịch họp', `Tạo cuộc họp "${title}"`, req.session.user.username, `${date} ${start_time}-${end_time} tại ${room}`);

  res.json({ ok: true, id: info.lastInsertRowid, notified: true });
});

// ══════════════════════════════════════════
// TÍNH NĂNG MỚI 4 - CHỈNH SỬA (EDIT) CUỘC HỌP ĐÃ TẠO
// ══════════════════════════════════════════
app.patch('/api/meetings/:id', requireAuth, (req, res) => {
  const m = db.prepare('SELECT * FROM meetings WHERE id = ?').get(req.params.id);
  if (!m) return res.status(404).json({ error: 'Không tìm thấy cuộc họp.' });
  if (m.creator_id !== req.session.user.id && req.session.user.role !== 'admin') {
    return res.status(403).json({ error: 'Bạn chỉ có thể chỉnh sửa cuộc họp do chính mình tạo.' });
  }

  let { title, date, start_time, end_time, room, force } = req.body;
  title = (title || '').trim();
  room = (room || '').trim();
  if (!title || !date || !start_time || !end_time || !room) {
    return res.status(400).json({ error: 'Vui lòng điền đầy đủ Tiêu đề, Ngày, Giờ bắt đầu/kết thúc, Phòng họp.' });
  }
  if (start_time >= end_time) {
    return res.status(400).json({ error: 'Giờ bắt đầu phải nhỏ hơn giờ kết thúc.' });
  }

  // <<include>> Kiểm tra trùng lịch phòng họp, loại trừ chính cuộc họp đang sửa
  const conflicts = db.prepare(`
    SELECT m.*, u.fullname as creator_name FROM meetings m
    JOIN users u ON u.id = m.creator_id
    WHERE m.date = ? AND m.room = ? AND m.id != ? AND (? < m.end_time AND ? > m.start_time)
  `).all(date, room, req.params.id, start_time, end_time);

  if (conflicts.length > 0 && !force) {
    return res.status(409).json({ conflict: true, conflicts });
  }

  const roomExists = db.prepare('SELECT id FROM rooms WHERE name = ?').get(room);
  if (!roomExists) {
    db.prepare('INSERT INTO rooms (name, color, is_custom) VALUES (?,?,1)').run(room, 'pink');
  }

  db.prepare(`UPDATE meetings SET title=?, date=?, start_time=?, end_time=?, room=? WHERE id=?`)
    .run(title, date, start_time, end_time, room, req.params.id);

  addLog('Lịch họp', `Chỉnh sửa cuộc họp "${title}"`, req.session.user.username, `${date} ${start_time}-${end_time} tại ${room}`);
  res.json({ ok: true });
});

// ══════════════════════════════════════════
// US10 - XÓA / HỦY LỊCH HỌP (chỉ người tạo)
// ══════════════════════════════════════════
app.delete('/api/meetings/:id', requireAuth, (req, res) => {
  const m = db.prepare('SELECT * FROM meetings WHERE id = ?').get(req.params.id);
  if (!m) return res.status(404).json({ error: 'Không tìm thấy cuộc họp.' });
  if (m.creator_id !== req.session.user.id && req.session.user.role !== 'admin') {
    return res.status(403).json({ error: 'Bạn chỉ có thể xóa cuộc họp do chính mình tạo.' });
  }
  db.prepare('DELETE FROM meetings WHERE id = ?').run(req.params.id);
  addLog('Lịch họp', `Xóa cuộc họp "${m.title}"`, req.session.user.username, '');
  res.json({ ok: true });
});

// ══════════════════════════════════════════
// PHÒNG HỌP (Room Manager)
// ══════════════════════════════════════════
app.get('/api/rooms', requireAuth, (req, res) => {
  res.json(db.prepare('SELECT * FROM rooms ORDER BY name').all());
});

app.post('/api/rooms', requireAuth, (req, res) => {
  const { name, capacity, floor, equipment } = req.body;
  if (!name) return res.status(400).json({ error: 'Tên phòng bắt buộc.' });
  const colors = ['indigo', 'purple', 'amber', 'pink', 'emerald', 'sky'];
  const color = colors[db.prepare('SELECT COUNT(*) c FROM rooms').get().c % colors.length];
  const info = db.prepare('INSERT INTO rooms (name, capacity, floor, equipment, color) VALUES (?,?,?,?,?)')
    .run(name, capacity || 0, floor || '', equipment || '', color);
  addLog('Hệ thống', `Thêm phòng họp mới ${name}`, req.session.user.username, '');
  res.json({ ok: true, id: info.lastInsertRowid });
});

app.patch('/api/rooms/:id/toggle', requireAuth, (req, res) => {
  const r = db.prepare('SELECT * FROM rooms WHERE id = ?').get(req.params.id);
  if (!r) return res.status(404).json({ error: 'Không tìm thấy phòng.' });
  const newStatus = r.status === 'available' ? 'maintenance' : 'available';
  db.prepare('UPDATE rooms SET status = ? WHERE id = ?').run(newStatus, req.params.id);
  res.json({ ok: true, status: newStatus });
});

app.delete('/api/rooms/:id', requireAuth, (req, res) => {
  if (req.session.user.role !== 'admin') return res.status(403).json({ error: 'Không có quyền.' });
  const r = db.prepare('SELECT * FROM rooms WHERE id = ?').get(req.params.id);
  if (!r) return res.status(404).json({ error: 'Không tìm thấy phòng.' });
  const inUse = db.prepare('SELECT COUNT(*) c FROM meetings WHERE room = ?').get(r.name).c;
  if (inUse > 0) {
    return res.status(409).json({ error: `Không thể xóa: phòng "${r.name}" đang được ${inUse} cuộc họp sử dụng.` });
  }
  db.prepare('DELETE FROM rooms WHERE id = ?').run(req.params.id);
  addLog('Hệ thống', `Xóa phòng họp ${r.name}`, req.session.user.username, '');
  res.json({ ok: true });
});

// ══════════════════════════════════════════
// ADMIN - QUẢN LÝ TÀI KHOẢN
// ══════════════════════════════════════════
app.get('/api/users', requireAuth, (req, res) => {
  if (req.session.user.role !== 'admin') return res.status(403).json({ error: 'Không có quyền.' });
  res.json(db.prepare('SELECT id, fullname, username, role, status, created_at, last_login FROM users').all());
});

app.patch('/api/users/:id/toggle-lock', requireAuth, (req, res) => {
  if (req.session.user.role !== 'admin') return res.status(403).json({ error: 'Không có quyền.' });
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!u) return res.status(404).json({ error: 'Không tìm thấy tài khoản.' });
  const newStatus = u.status === 'active' ? 'locked' : 'active';
  db.prepare('UPDATE users SET status = ? WHERE id = ?').run(newStatus, req.params.id);
  addLog('Tài khoản', `${newStatus === 'locked' ? 'Khóa' : 'Mở khóa'} tài khoản ${u.username}`, req.session.user.username, '');
  res.json({ ok: true, status: newStatus });
});

app.get('/api/logs', requireAuth, (req, res) => {
  res.json(db.prepare('SELECT * FROM logs ORDER BY time DESC LIMIT 200').all());
});

// ══════════════════════════════════════════
// ADMIN - QUẢN LÝ TOÀN BỘ CUỘC HỌP (xem/lọc/sửa/xóa mọi cuộc họp trong công ty)
// ══════════════════════════════════════════
app.get('/api/admin/meetings', requireAuth, (req, res) => {
  if (req.session.user.role !== 'admin') return res.status(403).json({ error: 'Không có quyền.' });
  const { q, room, creator_id, date_from, date_to } = req.query;
  let sql = `SELECT m.*, u.fullname as creator_name, u.username as creator_username,
             (SELECT COUNT(*) FROM participants p WHERE p.meeting_id = m.id) as participant_count
             FROM meetings m JOIN users u ON u.id = m.creator_id WHERE 1=1`;
  const params = [];
  if (q) { sql += ' AND m.title LIKE ?'; params.push(`%${q}%`); }
  if (room && room !== 'all') { sql += ' AND m.room = ?'; params.push(room); }
  if (creator_id && creator_id !== 'all') { sql += ' AND m.creator_id = ?'; params.push(creator_id); }
  if (date_from) { sql += ' AND m.date >= ?'; params.push(date_from); }
  if (date_to) { sql += ' AND m.date <= ?'; params.push(date_to); }
  sql += ' ORDER BY m.date DESC, m.start_time DESC';
  res.json(db.prepare(sql).all(...params));
});

app.listen(PORT, () => {
  console.log(`✅ MeetFlow server đang chạy tại http://localhost:${PORT}`);
});
