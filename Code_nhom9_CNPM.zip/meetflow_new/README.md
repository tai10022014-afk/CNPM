# MeetFlow – Hệ thống đặt lịch họp công ty XYZ

Backend Node.js + Express + SQLite (better-sqlite3), giao diện theo đúng
đặc tả UI trong tài liệu Sprint Backlog (mục 5.1 – 5.4): đăng nhập/đăng ký/
quên mật khẩu, dashboard lịch họp tuần, form đặt lịch với phòng tùy chọn/tự
nhập, kiểm tra & cảnh báo trùng lịch phòng.

## Cài đặt

Cần cài **Node.js** (bản LTS) trước: https://nodejs.org

```bash
cd meetflow
npm install
npm start
```

Sau đó mở trình duyệt: **http://localhost:3000**

Database `meetflow.db` (SQLite) sẽ tự động được tạo trong thư mục dự án ở
lần chạy đầu tiên — không cần cài đặt phần mềm database riêng (không cần
XAMPP/MySQL).

## Cấu trúc

```
meetflow/
├── server.js          # Backend: API đăng ký/đăng nhập/lịch họp/phòng họp
├── package.json
├── meetflow.db        # (tự tạo) SQLite database
└── public/
    ├── index.html      # Đăng nhập / Đăng ký / Quên mật khẩu
    └── dashboard.html  # Lịch họp tuần, form đặt lịch, quản lý phòng
```

## Các API chính

| Method | Endpoint | Mô tả |
|---|---|---|
| POST | /api/register | Đăng ký tài khoản (US01) |
| POST | /api/login | Đăng nhập (US02) |
| POST | /api/forgot-password | Khôi phục mật khẩu (US03) |
| GET | /api/meetings?q=&room= | Tìm kiếm/lọc lịch họp (US04,US05) |
| GET | /api/meetings/upcoming | Lịch họp sắp tới (US06) |
| POST | /api/meetings | Tạo lịch họp + kiểm tra trùng phòng (US07,US08) |
| DELETE | /api/meetings/:id | Xóa lịch họp do chính mình tạo (US10) |
| GET/POST | /api/rooms | Danh sách / thêm phòng họp |
| GET | /api/users | (Admin) danh sách tài khoản |
| PATCH | /api/users/:id/toggle-lock | (Admin) khóa/mở khóa tài khoản |

## Ghi chú bảo mật

Mật khẩu được băm bằng bcrypt trước khi lưu (`password_hash`). Cột
`password_plain` chỉ tồn tại để phục vụ đúng yêu cầu "quên mật khẩu hiển thị
mật khẩu hiện tại" trong đề bài — trong dự án thực tế nên thay bằng luồng gửi
link đặt lại mật khẩu qua email thay vì hiển thị trực tiếp.
